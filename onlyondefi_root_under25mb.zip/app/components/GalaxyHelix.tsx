"use client";

export function GalaxyHelix() { return null; }
